#!/bin/bash
xte 'str -'
